﻿using DataAccess.Repository.IRepository;
using DbModel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace WebApplication1.Areas.Admin.Controllers
{
    [Area("Admin")]
    [AllowAnonymous]
    public class CategoryController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;

        public CategoryController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public IActionResult Index()
        {

            IEnumerable<Employee> objCategoryList = _unitOfWork.employee.GetAll();
            return View(objCategoryList);
        }
        public IActionResult Details(int id)
        {
            var employee = _unitOfWork.employee.GetEmployeeWithFiles(id);

            if (employee == null)
            {
                return NotFound();
            }

            return View(employee);
        }


       
        [HttpPost]

        [AllowAnonymous]
        public async Task<IActionResult> UploadFile(int employeeId, IFormFile file)
        {
            if (await _unitOfWork.employee.UploadEmployeeFile(employeeId, file))
            {
                return RedirectToAction("Details", new { id = employeeId });
            }

            return RedirectToAction("Details", new { id = employeeId }); // You can handle the error scenario differently
        }

        public IActionResult DownloadFile(int id, bool view = false)
        {
            var employeeFile = _unitOfWork.employee.GetEmployeeFileById(id);
            if (employeeFile == null)
            {
                return NotFound();
            }

            if (view)
            {
                var fileStream = new FileStream(employeeFile.FilePath, FileMode.Open, FileAccess.Read);
                return File(fileStream, "text/plain");
            }
            else
            {
                var fileStream = new FileStream(employeeFile.FilePath, FileMode.Open, FileAccess.Read);
                return File(fileStream, "application/octet-stream", employeeFile.FileName);
            }
        }


        //[HttpPost]
        //public async Task<IActionResult> Upload(IFormFile file)
        //{
        //    if (file != null && file.Length > 0)
        //    {
        //        try
        //        {
        //            var fileName = Path.GetFileName(file.FileName);
        //            var filePath = Path.Combine("wwwroot", "uploads", fileName);

        //            using (var stream = new FileStream(filePath, FileMode.Create))
        //            {
        //                await file.CopyToAsync(stream);
        //            }

        //            // Create a new record for the database
        //            var fileRecord = new FileUpload
        //            {
        //                FileName = fileName,
        //                FilePath = filePath,
        //                UploadDate = DateTime.Now // You can use DateTime.UtcNow for UTC time
        //            };

        //            // Add the record to the repository
        //            await _unitOfWork.FILES.AddAsync(fileRecord);

        //            ViewBag.Message = "File uploaded successfully.";
        //        }
        //        catch (Exception ex)
        //        {
        //            ViewBag.Message = $"Error uploading file: {ex.Message}";
        //        }
        //    }
        //    else
        //    {
        //        ViewBag.Message = "Please choose a file to upload.";
        //    }

        //    return View();
        //}
        public IActionResult Upload()
        {
            // Assuming you have a file repository injected as _fileUploadRepository
            var files = _unitOfWork.FILES.GetAllAsync().Result; // Synchronous call for simplicity

            return View(files);
        }
        [HttpPost]
        public async Task<IActionResult> Upload(IFormFile file)
        {
            if (file != null && file.Length > 0)
            {
                try
                {
                    var fileName = Path.GetFileName(file.FileName);
                    var filePath = Path.Combine("wwwroot", "uploads", fileName);

                    using (var stream = new FileStream(filePath, FileMode.Create))
                    {
                        await file.CopyToAsync(stream);
                    }

                    // Create a new record for the database
                    var fileRecord = new FileUpload
                    {
                        FileName = fileName,
                        FilePath = filePath,
                        UploadDate = DateTime.Now // You can use DateTime.UtcNow for UTC time
                    };

                    // Add the record to the repository
                    await _unitOfWork.FILES.AddAsync(fileRecord);

                    ViewBag.Message = "File uploaded successfully.";
                }
                catch (Exception ex)
                {
                    ViewBag.Message = $"Error uploading file: {ex.Message}";
                }
            }
            else
            {
                ViewBag.Message = "Please choose a file to upload.";
            }

            // Fetch the list of uploaded files and pass them to the view
            var uploadedFiles = await _unitOfWork.FILES.GetAllAsync();

            return View("Upload", uploadedFiles); // Assuming your view is named "Upload.cshtml"
        }

    }
}
