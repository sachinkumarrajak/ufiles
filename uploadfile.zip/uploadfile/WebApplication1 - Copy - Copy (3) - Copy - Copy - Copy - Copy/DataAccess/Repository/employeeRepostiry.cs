﻿using DataAccess.Data;
using DataAccess.Repository.IRepository;
using DbModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Repository
{
    internal class employeeRepostiry : Repository<Employee>, Iemployee
    {
        private ApplicationDbContext _db;

        public employeeRepostiry(ApplicationDbContext db) : base(db)
        {
            _db = db;
        }


        public void Update(Employee obj)
        {
            _db.Employees.Update(obj);
        }
    }
}
