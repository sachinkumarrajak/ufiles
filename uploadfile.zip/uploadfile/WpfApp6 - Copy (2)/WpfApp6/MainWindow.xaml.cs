﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp6
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Timer fileProcessTimer;
        private string directoryToMonitor = @"C:\file"; // Replace with your directory path
        private string apiEndpoint = "https://localhost:7256/Employee/UploadFile";
        private bool isProcessingFile = false; // Flag to prevent concurrent processing
        private DateTime lastProcessingTime = DateTime.MinValue;

        public MainWindow()
        {
            InitializeComponent();
            fileProcessTimer = new Timer(ProcessFiles, null, TimeSpan.Zero, TimeSpan.FromMinutes(2));
            // fileProcessTimer = new Timer(ProcessFiles, null, TimeSpan.Zero, TimeSpan.FromMinutes(15));
            //fileCheckTimer = new System.Timers.Timer();
            //fileCheckTimer.Interval = 5000; // 5 seconds interval (adjust as needed)
            //fileCheckTimer.Elapsed += FileCheckTimer_Elapsed;
            //fileCheckTimer.Start();
        }
        private void ProcessFiles(object state)
        {
            // Check if another file is currently being processed
            if (isProcessingFile)
            {
                return;
            }

            // Set the flag to indicate processing
            isProcessingFile = true;

            try
            {
                // Get files modified since the last processing
                string[] files = Directory.GetFiles(directoryToMonitor)
                                         .Where(file => File.GetLastWriteTime(file) > lastProcessingTime)
                                         .ToArray();

                if (files.Length > 0)
                {
                    // Process the files that have been modified
                    foreach (string filePath in files)
                    {
                        UploadFile(1,filePath);
                    }

                    // Update the last processing time
                    lastProcessingTime = DateTime.Now;
                }
            }
            finally
            {
                // Reset the flag after processing
                isProcessingFile = false;
            }
        }

        //private void ProcessFiles(object state)
        //{
        //    // Check if another file is currently being processed
        //    if (isProcessingFile)
        //    {
        //        return;
        //    }

        //    // Set the flag to indicate processing
        //    isProcessingFile = true;

        //    try
        //    {
        //        string[] files = Directory.GetFiles(directoryToMonitor);

        //        if (files.Length > 0)
        //        {
        //            // Process the first file found
        //            UploadFile(files[0]);
        //        }
        //    }
        //    finally
        //    {
        //        // Reset the flag after processing
        //        isProcessingFile = false;
        //    }
        //}
        private void FileProcessTimerCallback(object state)
        {
            if (!isProcessingFile)
            {
                isProcessingFile = true;

                string[] files = Directory.GetFiles(directoryToMonitor);

                if (files.Length > 0)
                {
                    // Process the first file found
                    UploadFile(1,files[0]);
                }

                isProcessingFile = false;
            }
        }
        private void FileCheckTimer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            // Simulate the file watcher behavior by periodically checking for new files
            string[] files = Directory.GetFiles(directoryToMonitor);

            foreach (string filePath in files)
            {
                // Trigger the file upload logic for each new file found
                UploadFile(1, filePath);
            }
        }
        private void UploadFile(int employeeId, string filePath)
        {
            var apiEndpoint = "https://localhost:7256/Employee/UploadFile"; // Replace with your actual API endpoint URL
            var fileName = System.IO.Path.GetFileName(filePath);
            var boundary = "----------------------------" + DateTime.Now.Ticks.ToString("x");

            var request = (HttpWebRequest)WebRequest.Create(apiEndpoint);
            request.Method = "POST";
            request.ContentType = "multipart/form-data; boundary=" + boundary;

            using (var requestStream = request.GetRequestStream())
            using (var writer = new StreamWriter(requestStream))
            {
                writer.WriteLine("--" + boundary);
                writer.WriteLine("Content-Disposition: form-data; name=\"employeeId\"");
                writer.WriteLine();
                writer.WriteLine(employeeId.ToString());
                writer.WriteLine("--" + boundary);
                writer.WriteLine("Content-Disposition: form-data; name=\"file\"; filename=\"" + fileName + "\"");
                writer.WriteLine("Content-Type: application/octet-stream");
                writer.WriteLine();
                writer.Flush();

                using (var fileStream = File.OpenRead(filePath))
                {
                    byte[] buffer = new byte[4096];
                    int bytesRead;
                    while ((bytesRead = fileStream.Read(buffer, 0, buffer.Length)) > 0)
                    {
                        requestStream.Write(buffer, 0, bytesRead);
                    }
                }

                writer.WriteLine();
                writer.WriteLine("--" + boundary + "--");
                writer.Flush();
            }

            using (var response = (HttpWebResponse)request.GetResponse())
            using (var responseStream = response.GetResponseStream())
            using (var reader = new StreamReader(responseStream))
            {
                var responseText = reader.ReadToEnd();
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    Console.WriteLine("File successfully uploaded!");
                }
                else
                {
                    Console.WriteLine("File upload failed. Response: " + responseText);
                }
            }
        }


        //private void UploadFile(string filePath)
        //{
        //    // Your existing file upload logic
        //    // Make sure to use the provided filePath to read the file content

        //    // ...
        //    using (var fileStream = File.OpenRead(filePath))
        //    {
        //        var fileName = System.IO.Path.GetFileName(filePath);
        //        var boundary = "----------------------------" + DateTime.Now.Ticks.ToString("x");

        //        var request = (HttpWebRequest)WebRequest.Create(apiEndpoint);
        //        request.Method = "POST";
        //        request.ContentType = "multipart/form-data; boundary=" + boundary;

        //        using (var requestStream = request.GetRequestStream())
        //        using (var writer = new StreamWriter(requestStream))
        //        {
        //            writer.WriteLine("--" + boundary);
        //            writer.WriteLine("Content-Disposition: form-data; name=\"file\"; filename=\"" + fileName + "\"");
        //            writer.WriteLine("Content-Type: application/octet-stream");
        //            writer.WriteLine();
        //            writer.Flush();

        //            fileStream.CopyTo(requestStream);

        //            writer.WriteLine();
        //            writer.WriteLine("--" + boundary + "--");
        //            writer.Flush();
        //        }

        //        using (var response = (HttpWebResponse)request.GetResponse())
        //        using (var responseStream = response.GetResponseStream())
        //        using (var reader = new StreamReader(responseStream))
        //        {
        //            var responseText = reader.ReadToEnd();
        //            if (response.StatusCode == HttpStatusCode.OK)
        //            {
        //                Console.WriteLine("File successfully uploaded!");
        //            }
        //            else
        //            {
        //                Console.WriteLine("File upload failed. Response: " + responseText);
        //            }
        //        }
        //    }
        //}
        private void button_Click(object sender, RoutedEventArgs e)
        {
            string filePath = @"C:\SACHIN\angular\MVC\MVC6Crud\MVC6Crud\dxdiag_info.txt";
            string apiEndpoint = "https://localhost:7256/up/UploadFile";

            using (var fileStream = File.OpenRead(filePath))
            {
                var fileName = System.IO.Path.GetFileName(filePath);
                var boundary = "----------------------------" + DateTime.Now.Ticks.ToString("x");

                var request = (HttpWebRequest)WebRequest.Create(apiEndpoint);
                request.Method = "POST";
                request.ContentType = "multipart/form-data; boundary=" + boundary;

                using (var requestStream = request.GetRequestStream())
                using (var writer = new StreamWriter(requestStream))
                {
                    writer.WriteLine("--" + boundary);
                    writer.WriteLine("Content-Disposition: form-data; name=\"file\"; filename=\"" + fileName + "\"");
                    writer.WriteLine("Content-Type: application/octet-stream");
                    writer.WriteLine();
                    writer.Flush();

                    fileStream.CopyTo(requestStream);

                    writer.WriteLine();
                    writer.WriteLine("--" + boundary + "--");
                    writer.Flush();
                }

                using (var response = (HttpWebResponse)request.GetResponse())
                using (var responseStream = response.GetResponseStream())
                using (var reader = new StreamReader(responseStream))
                {
                    var responseText = reader.ReadToEnd();
                    if (response.StatusCode == HttpStatusCode.OK)
                    {
                        Console.WriteLine("File successfully uploaded!");
                    }
                    else
                    {
                        Console.WriteLine("File upload failed. Response: " + responseText);
                    }
                }
            }
        }

    }
}
