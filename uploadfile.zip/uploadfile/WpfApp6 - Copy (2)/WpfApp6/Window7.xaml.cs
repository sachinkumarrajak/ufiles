﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp6
{
    /// <summary>
    /// Interaction logic for Window7.xaml
    /// </summary>
    public partial class Window7 : Window
    {
        private FileSystemWatcher watcher;
        private readonly object lockObject = new object();
        public Window7()
        {
            InitializeComponent();
            InitializeFileSystemWatcher();
            ProcessExistingFiles(); // Process existing files after initializing the watcher
        }
        private void InitializeFileSystemWatcher()
        {
            // Set up the file system watcher
            watcher = new FileSystemWatcher();
            watcher.Path = @"C:\filepass"; // Replace with your source folder path
            watcher.Filter = "*.*"; // Monitor all files, you can adjust this as needed
            watcher.IncludeSubdirectories = true;

            // Attach event handlers
            watcher.Created += OnFileChanged;
            watcher.Changed += OnFileChanged;

            // Start watching
            watcher.EnableRaisingEvents = true;
        }

        private void ProcessExistingFiles()
        {
            string sourcePath = @"C:\filepass"; // Replace with your source folder path
            string[] existingFiles = Directory.GetFiles(sourcePath, "*.*", SearchOption.AllDirectories);

            foreach (string filePath in existingFiles)
            {
                OnFileChanged(this, new FileSystemEventArgs(WatcherChangeTypes.Changed, System.IO.Path.GetDirectoryName(filePath), System.IO.Path.GetFileName(filePath)));
            }
        }

        private void OnFileChanged(object sender, FileSystemEventArgs e)
        {
            Thread thread = new Thread(() =>
            {
                lock (lockObject)
                {
                    // Copy the file to the destination folder
                   // string destinationPath = @"C:\file2"; // Replace with your destination folder path
                    string fileName = System.IO.Path.GetFileName(e.FullPath);
                    //  string destinationFilePath = System.IO.Path.Combine(destinationPath, fileName);
                    DateTime lastModifiedDate = File.GetLastWriteTime(e.FullPath);
                    try
                    {
                        // Use File.Exists to check if the source file exists
                        if (File.Exists(e.FullPath))
                        {
                           UploadFile(2, e.FullPath);
                            // You can add additional logic here, such as updating the UI or logging
                        }
                    }
                    catch (Exception ex)
                    {
                        // Handle exceptions
                        MessageBox.Show("An error occurred: " + ex.Message);
                    }
                }
            });

            thread.Start();
        }


        private void UploadFile(int employeeId, string filePath)
        {
            try
            {
                var apiEndpoint = "https://localhost:7039/admin/Mes/UploadFile"; // Replace with your actual API endpoint URL
                var fileName = System.IO.Path.GetFileName(filePath);
                var boundary = "----------------------------" + DateTime.Now.Ticks.ToString("x");

                var request = (HttpWebRequest)WebRequest.Create(apiEndpoint);
                request.Method = "POST";
                request.ContentType = "multipart/form-data; boundary=" + boundary;

                using (var requestStream = request.GetRequestStream())
                using (var writer = new StreamWriter(requestStream))
                {
                    writer.WriteLine("--" + boundary);
                    writer.WriteLine("Content-Disposition: form-data; name=\"employeeId\"");
                    writer.WriteLine();
                    writer.WriteLine(employeeId.ToString());
                    writer.WriteLine("--" + boundary);
                    writer.WriteLine("Content-Disposition: form-data; name=\"file\"; filename=\"" + fileName + "\"");
                    writer.WriteLine("Content-Type: application/octet-stream");
                    writer.WriteLine();
                    writer.Flush();

                    using (var fileStream = File.OpenRead(filePath))
                    {
                        byte[] buffer = new byte[4096];
                        int bytesRead;
                        while ((bytesRead = fileStream.Read(buffer, 0, buffer.Length)) > 0)
                        {
                            requestStream.Write(buffer, 0, bytesRead);
                        }
                    }

                    writer.WriteLine();
                    writer.WriteLine("--" + boundary + "--");
                    writer.Flush();
                }

                using (var response = (HttpWebResponse)request.GetResponse())
                using (var responseStream = response.GetResponseStream())
                using (var reader = new StreamReader(responseStream))
                {
                    var responseText = reader.ReadToEnd();
                    if (response.StatusCode == HttpStatusCode.OK)
                    {
                        Console.WriteLine("File successfully uploaded!");
                    }
                    else
                    {
                        Console.WriteLine("File upload failed. Response: " + responseText);
                    }
                }
            }
          catch(Exception ex) { }
            //var apiEndpoint = "https://localhost:7039/Admin/Mes/UploadFile/"; // Replace with your actual API endpoint URL
            //var fileName = System.IO.Path.GetFileName(filePath);
            //var boundary = "----------------------------" + DateTime.Now.Ticks.ToString("x");

            //var request = (HttpWebRequest)WebRequest.Create(apiEndpoint);
            //request.Method = "POST";
            //request.ContentType = "multipart/form-data; boundary=" + boundary;

            //using (var requestStream = request.GetRequestStream())
            //using (var writer = new StreamWriter(requestStream))
            //{
            //    writer.WriteLine("--" + boundary);
            //    writer.WriteLine("Content-Disposition: form-data; name=\"employeeId\"");
            //    writer.WriteLine();
            //    writer.WriteLine(employeeId.ToString());
            //    writer.WriteLine("--" + boundary);
            //    writer.WriteLine("Content-Disposition: form-data; name=\"file\"; filename=\"" + fileName + "\"");
            //    writer.WriteLine("Content-Type: application/octet-stream");
            //    writer.WriteLine();
            //    writer.Flush();

            //    using (var fileStream = File.OpenRead(filePath))
            //    {
            //        byte[] buffer = new byte[4096];
            //        int bytesRead;
            //        while ((bytesRead = fileStream.Read(buffer, 0, buffer.Length)) > 0)
            //        {
            //            requestStream.Write(buffer, 0, bytesRead);
            //        }
            //    }

            //    writer.WriteLine();
            //    writer.WriteLine("--" + boundary + "--");
            //    writer.Flush();
            //}

            //using (var response = (HttpWebResponse)request.GetResponse())
            //using (var responseStream = response.GetResponseStream())
            //using (var reader = new StreamReader(responseStream))
            //{
            //    var responseText = reader.ReadToEnd();
            //    if (response.StatusCode == HttpStatusCode.OK)
            //    {
            //        Console.WriteLine("File successfully uploaded!");
            //    }
            //    else
            //    {
            //        Console.WriteLine("File upload failed. Response: " + responseText);
            //    }
            //}
        }

        private void UploadFile(int employeeId, string filePath, DateTime lastModifiedDate)
        {
            try
            {
                var apiEndpoint = "https://localhost:7039/admin/Mes/UploadFile"; // Replace with your actual API endpoint URL
                var fileName = System.IO.Path.GetFileName(filePath);
                var boundary = "----------------------------" + DateTime.Now.Ticks.ToString("x");

                var request = (HttpWebRequest)WebRequest.Create(apiEndpoint);
                request.Method = "POST";
                request.ContentType = "multipart/form-data; boundary=" + boundary;

                using (var requestStream = request.GetRequestStream())
                using (var writer = new StreamWriter(requestStream))
                {
                    writer.WriteLine("--" + boundary);
                    writer.WriteLine("Content-Disposition: form-data; name=\"employeeId\"");
                    writer.WriteLine();
                    writer.WriteLine(employeeId.ToString());
                    writer.WriteLine("--" + boundary);
                    writer.WriteLine("Content-Disposition: form-data; name=\"file\"; filename=\"" + fileName + "\"");
                    writer.WriteLine("Content-Type: application/octet-stream");
                    writer.WriteLine();
                    writer.WriteLine("--" + boundary);
                    writer.WriteLine("Content-Disposition: form-data; name=\"lastModifiedDate\"");
                    writer.WriteLine("Content-Type: text/plain");
                    writer.WriteLine();
                    writer.WriteLine(lastModifiedDate.ToString("yyyy-MM-dd HH:mm:ss")); // Convert to a suitable format
                    writer.WriteLine("--" + boundary);
                    writer.Flush();

                    using (var fileStream = File.OpenRead(filePath))
                    {
                        byte[] buffer = new byte[4096];
                        int bytesRead;
                        while ((bytesRead = fileStream.Read(buffer, 0, buffer.Length)) > 0)
                        {
                            requestStream.Write(buffer, 0, bytesRead);
                        }
                    }

                    writer.WriteLine();
                    writer.WriteLine("--" + boundary + "--");
                    writer.Flush();
                }

                using (var response = (HttpWebResponse)request.GetResponse())
                using (var responseStream = response.GetResponseStream())
                using (var reader = new StreamReader(responseStream))
                {
                    var responseText = reader.ReadToEnd();
                    if (response.StatusCode == HttpStatusCode.OK)
                    {
                        Console.WriteLine("File successfully uploaded!");
                    }
                    else
                    {
                        Console.WriteLine("File upload failed. Response: " + responseText);
                    }
                }
            }
            catch (Exception ex) { }
        }

    }
}
