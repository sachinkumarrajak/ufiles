﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


namespace WpfApp6
{
    /// <summary>
    /// Interaction logic for Window6.xaml
    /// </summary>
    public partial class Window6 : Window
    {
        public Window6()
        {
            InitializeComponent();

        }
        private void button_Click(object sender, RoutedEventArgs e)
        {
            int employeeId = 2;
            string filePath = @"C:\file\sachin - Copy.txt";
            UploadFile(employeeId, filePath);
        }
        private void UploadFile(int employeeId, string filePath)
        {
            try
            {
                var apiEndpoint = "https://localhost:7039/admin/Mes/UploadFile"; // Replace with your actual API endpoint URL
                var fileName = System.IO.Path.GetFileName(filePath);
                var boundary = "----------------------------" + DateTime.Now.Ticks.ToString("x");

                var request = (HttpWebRequest)WebRequest.Create(apiEndpoint);
                request.Method = "POST";
                request.ContentType = "multipart/form-data; boundary=" + boundary;

                using (var requestStream = request.GetRequestStream())
                using (var writer = new StreamWriter(requestStream))
                {
                    writer.WriteLine("--" + boundary);
                    writer.WriteLine("Content-Disposition: form-data; name=\"employeeId\"");
                    writer.WriteLine();
                    writer.WriteLine(employeeId.ToString());
                    writer.WriteLine("--" + boundary);
                    writer.WriteLine("Content-Disposition: form-data; name=\"file\"; filename=\"" + fileName + "\"");
                    writer.WriteLine("Content-Type: application/octet-stream");
                    writer.WriteLine();
                    writer.Flush();

                    using (var fileStream = File.OpenRead(filePath))
                    {
                        byte[] buffer = new byte[4096];
                        int bytesRead;
                        while ((bytesRead = fileStream.Read(buffer, 0, buffer.Length)) > 0)
                        {
                            requestStream.Write(buffer, 0, bytesRead);
                        }
                    }

                    writer.WriteLine();
                    writer.WriteLine("--" + boundary + "--");
                    writer.Flush();
                }

                using (var response = (HttpWebResponse)request.GetResponse())
                using (var responseStream = response.GetResponseStream())
                using (var reader = new StreamReader(responseStream))
                {
                    var responseText = reader.ReadToEnd();
                    if (response.StatusCode == HttpStatusCode.OK)
                    {
                        Console.WriteLine("File successfully uploaded!");
                    }
                    else
                    {
                        Console.WriteLine("File upload failed. Response: " + responseText);
                    }
                }
            }
            catch(Exception ex)
            {

            }
           
            //var apiEndpoint = "https://localhost:7039/Admin/Mes/UploadFile/"; // Replace with your actual API endpoint URL
            //var fileName = System.IO.Path.GetFileName(filePath);
            //var boundary = "----------------------------" + DateTime.Now.Ticks.ToString("x");

            //var request = (HttpWebRequest)WebRequest.Create(apiEndpoint);
            //request.Method = "POST";
            //request.ContentType = "multipart/form-data; boundary=" + boundary;

            //using (var requestStream = request.GetRequestStream())
            //using (var writer = new StreamWriter(requestStream))
            //{
            //    writer.WriteLine("--" + boundary);
            //    writer.WriteLine("Content-Disposition: form-data; name=\"employeeId\"");
            //    writer.WriteLine();
            //    writer.WriteLine(employeeId.ToString());
            //    writer.WriteLine("--" + boundary);
            //    writer.WriteLine("Content-Disposition: form-data; name=\"file\"; filename=\"" + fileName + "\"");
            //    writer.WriteLine("Content-Type: application/octet-stream");
            //    writer.WriteLine();
            //    writer.Flush();

            //    using (var fileStream = File.OpenRead(filePath))
            //    {
            //        byte[] buffer = new byte[4096];
            //        int bytesRead;
            //        while ((bytesRead = fileStream.Read(buffer, 0, buffer.Length)) > 0)
            //        {
            //            requestStream.Write(buffer, 0, bytesRead);
            //        }
            //    }

            //    writer.WriteLine();
            //    writer.WriteLine("--" + boundary + "--");
            //    writer.Flush();
            //}

            //using (var response = (HttpWebResponse)request.GetResponse())
            //using (var responseStream = response.GetResponseStream())
            //using (var reader = new StreamReader(responseStream))
            //{
            //    var responseText = reader.ReadToEnd();
            //    if (response.StatusCode == HttpStatusCode.OK)
            //    {
            //        Console.WriteLine("File successfully uploaded!");
            //    }
            //    else
            //    {
            //        Console.WriteLine("File upload failed. Response: " + responseText);
            //    }
            //}
        }
        private async void SendButton_Click(object sender, RoutedEventArgs e)
        {
            using (HttpClient httpClient = new HttpClient())
            {
                // Set the base address for your API
                httpClient.BaseAddress = new Uri("https://localhost:7039/");

                try
                {
                    // Send a GET request to the specified URL
                    HttpResponseMessage response = await httpClient.GetAsync("admin/Mes/PrintMessage");

                    // Check if the response is successful
                    if (response.IsSuccessStatusCode)
                    {
                        // Read the response content (the message sent from the API)
                        string message = await response.Content.ReadAsStringAsync();

                        // Display the received message
                        Console.WriteLine("Received message from API: " + message);
                    }
                    else
                    {
                        Console.WriteLine("Failed to retrieve message from API. Status code: " + response.StatusCode);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("An error occurred: " + ex.Message);
                }
            }
            //string message = textBox.Text;

            //if (string.IsNullOrWhiteSpace(message))
            //{
            //    MessageBox.Show("Please enter a message.");
            //    return;
            //}

            //try
            //{
            //    using (var httpClient = new HttpClient())
            //    {
            //        var content = new StringContent(message, Encoding.UTF8, "application/json");

            //        HttpResponseMessage response = await httpClient.PostAsync("https://localhost:7039/admin/Mes/PrintMessage", content);

            //        if (response.IsSuccessStatusCode)
            //        {
            //            MessageBox.Show("Message sent successfully.");
            //        }
            //        else
            //        {
            //            MessageBox.Show("Failed to send message. Server returned: " + response.StatusCode);
            //        }
            //    }
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show("An error occurred: " + ex.Message);
            //}
        }
    }
   

    
}
