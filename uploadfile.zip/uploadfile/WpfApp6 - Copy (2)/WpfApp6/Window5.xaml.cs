﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp6
{
    /// <summary>
    /// Interaction logic for Window5.xaml
    /// </summary>
    public partial class Window5 : Window
    {
        private HashSet<string> processedFiles = new HashSet<string>();
       // private object lockObject = new object();
        private FileSystemWatcher watcher;
       // private readonly object lockObject = new object();
        private Dictionary<string, DateTime> lastModifiedTimes = new Dictionary<string, DateTime>();
        private object lockObject = new object();

        public Window5()
        {
            InitializeComponent();
            InitializeFileSystemWatcher();
        }
        private void OnFileChanged(object sender, FileSystemEventArgs e)
        {
            Thread thread = new Thread(() =>
            {
                lock (lockObject)
                {
                    // Check if this file has already been processed
                    if (lastModifiedTimes.ContainsKey(e.FullPath))
                    {
                        DateTime lastModified = File.GetLastWriteTime(e.FullPath);
                        if (lastModified == lastModifiedTimes[e.FullPath])
                        {
                            // File has not been updated, skip it
                            return;
                        }
                    }

                    // Update the last modified time for this file
                    lastModifiedTimes[e.FullPath] = File.GetLastWriteTime(e.FullPath);

                    // Copy the file to the destination folder
                    string destinationPath = @"C:\file1"; // Replace with your destination folder path
                    string fileName = System.IO.Path.GetFileName(e.FullPath);
                    string destinationFilePath = System.IO.Path.Combine(destinationPath, fileName);

                    try
                    {
                        // Use File.Exists to check if the source file exists
                        if (File.Exists(e.FullPath))
                        {
                            // File.Copy(e.FullPath, destinationFilePath, true);
                            UploadFile(1, e.FullPath);
                            // You can add additional logic here, such as updating the UI or logging
                        }
                    }
                    catch (Exception ex)
                    {
                        // Handle exceptions
                        MessageBox.Show("An error occurred: " + ex.Message);
                    }
                }
            });

            thread.Start();
        }
        //private void OnFileChanged(object sender, FileSystemEventArgs e)
        //{
        //    Thread thread = new Thread(() =>
        //    {
        //        lock (lockObject)
        //        {
        //            // Check if this file has already been processed
        //            if (processedFiles.Contains(e.FullPath))
        //            {
        //                // File has already been processed in this execution, skip it
        //                return;
        //            }

        //            // Add the file to the processed files set
        //            processedFiles.Add(e.FullPath);

        //            // Copy the file to the destination folder
        //            string destinationPath = @"C:\file1"; // Replace with your destination folder path
        //            string fileName = System.IO.Path.GetFileName(e.FullPath);
        //            string destinationFilePath = System.IO.Path.Combine(destinationPath, fileName);

        //            try
        //            {
        //                // Use File.Exists to check if the source file exists
        //                if (File.Exists(e.FullPath))
        //                {
        //                    // File.Copy(e.FullPath, destinationFilePath, true);
        //                    UploadFile(1, e.FullPath);
        //                    // You can add additional logic here, such as updating the UI or logging
        //                }
        //            }
        //            catch (Exception ex)
        //            {
        //                // Handle exceptions
        //                MessageBox.Show("An error occurred: " + ex.Message);
        //            }
        //        }
        //    });

        //    thread.Start();
        //}
        private void InitializeFileSystemWatcher()
        {
            // Set up the file system watcher
            watcher = new FileSystemWatcher();
            watcher.Path = @"C:\file"; // Replace with your source folder path
            watcher.Filter = "*.*"; // Monitor all files, you can adjust this as needed
            watcher.IncludeSubdirectories = true;

            // Attach event handlers
            watcher.Created += OnFileChanged;
            watcher.Changed += OnFileChanged;

            // Start watching
            watcher.EnableRaisingEvents = true;
        }
        //private void OnFileChanged(object sender, FileSystemEventArgs e)
        //{
        //    Thread thread = new Thread(() =>
        //    {
        //        lock (lockObject)
        //        {
        //            // Copy the file to the destination folder
        //            string destinationPath = @"C:\file1"; // Replace with your destination folder path
        //            string fileName = System.IO.Path.GetFileName(e.FullPath);
        //            string destinationFilePath = System.IO.Path.Combine(destinationPath, fileName);

        //            try
        //            {
        //                // Use File.Exists to check if the source file exists
        //                if (File.Exists(e.FullPath))
        //                {
        //                    //File.Copy(e.FullPath, destinationFilePath, true);
        //                    UploadFile(1, e.FullPath);
        //                    // You can add additional logic here, such as updating the UI or logging
        //                }
        //            }
        //            catch (Exception ex)
        //            {
        //                // Handle exceptions
        //                MessageBox.Show("An error occurred: " + ex.Message);
        //            }
        //        }
        //    });

        //    thread.Start();
        //}
        private void UploadFile(int employeeId, string filePath)
        {
            var apiEndpoint = "https://localhost:7256/Fileview/UploadFiles"; // Replace with your actual API endpoint URL
            var fileName = System.IO.Path.GetFileName(filePath);
            var boundary = "----------------------------" + DateTime.Now.Ticks.ToString("x");

            var request = (HttpWebRequest)WebRequest.Create(apiEndpoint);
            request.Method = "POST";
            request.ContentType = "multipart/form-data; boundary=" + boundary;

            using (var requestStream = request.GetRequestStream())
            using (var writer = new StreamWriter(requestStream))
            {
                writer.WriteLine("--" + boundary);
                writer.WriteLine("Content-Disposition: form-data; name=\"employeeId\"");
                writer.WriteLine();
                writer.WriteLine(employeeId.ToString());
                writer.WriteLine("--" + boundary);
                writer.WriteLine("Content-Disposition: form-data; name=\"file\"; filename=\"" + fileName + "\"");
                writer.WriteLine("Content-Type: application/octet-stream");
                writer.WriteLine();
                writer.Flush();

                using (var fileStream = File.OpenRead(filePath))
                {
                    byte[] buffer = new byte[4096];
                    int bytesRead;
                    while ((bytesRead = fileStream.Read(buffer, 0, buffer.Length)) > 0)
                    {
                        requestStream.Write(buffer, 0, bytesRead);
                    }
                }

                writer.WriteLine();
                writer.WriteLine("--" + boundary + "--");
                writer.Flush();
            }

            using (var response = (HttpWebResponse)request.GetResponse())
            using (var responseStream = response.GetResponseStream())
            using (var reader = new StreamReader(responseStream))
            {
                var responseText = reader.ReadToEnd();
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    Console.WriteLine("File successfully uploaded!");
                }
                else
                {
                    Console.WriteLine("File upload failed. Response: " + responseText);
                }
            }
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            string downloadUrl = "https://localhost:7256/Updw/DownloadFile"; 

            using (WebClient webClient = new WebClient())
            {
                try
                {
                    webClient.DownloadFile(downloadUrl, "downloaded_file.exe");

                    string exePath = @"downloaded_file.exe";
                    string arguments = "/s"; // This argument is generally used for silent installations

                    ProcessStartInfo startInfo = new ProcessStartInfo();
                    startInfo.FileName = "cmd.exe";
                    startInfo.Arguments = $"/C \"{exePath}\" {arguments}";
                    startInfo.WindowStyle = ProcessWindowStyle.Hidden; // Hide the command prompt window
                    startInfo.Verb = "runas"; // Request admin privileges

                    using (Process process = new Process())
                    {
                        process.StartInfo = startInfo;
                        process.Start();
                        process.WaitForExit(); // Wait for the installation process to finish
                    }
                    //  MessageBox.Show("File downloaded successfully.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error downloading file: {ex.Message}");
                }
            }
        }
    }
}
