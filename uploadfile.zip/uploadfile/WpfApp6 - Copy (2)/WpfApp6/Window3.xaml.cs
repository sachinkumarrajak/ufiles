﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp6
{
    /// <summary>
    /// Interaction logic for Window3.xaml
    /// </summary>
    public partial class Window3 : Window
    {

        private FileSystemWatcher watcher;
        private readonly object lockObject = new object();
        public Window3()
        {
            InitializeComponent();
        }

        private void DownloadButton_Click(object sender, RoutedEventArgs e)
        {
            string downloadUrl = "https://localhost:7256/Updw/DownloadFile"; // Replace with the URL of your download endpoint

            using (WebClient webClient = new WebClient())
            {
                try
                {
                    webClient.DownloadFile(downloadUrl, "downloaded_file.exe");
                    MessageBox.Show("File downloaded successfully.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error downloading file: {ex.Message}");
                }
            }
        }


    }
}
