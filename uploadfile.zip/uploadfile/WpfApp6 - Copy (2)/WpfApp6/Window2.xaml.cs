﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp6
{
    /// <summary>
    /// Interaction logic for Window2.xaml
    /// </summary>
    public partial class Window2 : Window
    {
        private FileSystemWatcher watcher;
        private readonly object lockObject = new object();

        public Window2()
        {
            InitializeComponent();
            InitializeFileSystemWatcher();
            ProcessExistingFiles(); // Process existing files after initializing the watcher
        }
        private void InitializeFileSystemWatcher()
        {
            // Set up the file system watcher
            watcher = new FileSystemWatcher();
            watcher.Path = @"C:\file"; // Replace with your source folder path
            watcher.Filter = "*.*"; // Monitor all files, you can adjust this as needed
            watcher.IncludeSubdirectories = true;

            // Attach event handlers
            watcher.Created += OnFileChanged;
            watcher.Changed += OnFileChanged;

            // Start watching
            watcher.EnableRaisingEvents = true;
        }

        private void ProcessExistingFiles()
        {
            string sourcePath = @"C:\file"; // Replace with your source folder path
            string[] existingFiles = Directory.GetFiles(sourcePath, "*.*", SearchOption.AllDirectories);

            foreach (string filePath in existingFiles)
            {
                OnFileChanged(this, new FileSystemEventArgs(WatcherChangeTypes.Changed, System.IO.Path.GetDirectoryName(filePath), System.IO.Path.GetFileName(filePath)));
            }
        }

        private void OnFileChanged(object sender, FileSystemEventArgs e)
        {
            Thread thread = new Thread(() =>
            {
                lock (lockObject)
                {
                    // Copy the file to the destination folder
                    string destinationPath = @"C:\file1"; // Replace with your destination folder path
                    string fileName = System.IO.Path.GetFileName(e.FullPath);
                    string destinationFilePath = System.IO.Path.Combine(destinationPath, fileName);

                    try
                    {
                        // Use File.Exists to check if the source file exists
                        if (File.Exists(e.FullPath))
                        {
                            File.Copy(e.FullPath, destinationFilePath, true);
                            // You can add additional logic here, such as updating the UI or logging
                        }
                    }
                    catch (Exception ex)
                    {
                        // Handle exceptions
                        MessageBox.Show("An error occurred: " + ex.Message);
                    }
                }
            });

            thread.Start();
        }
        //private void InitializeFileSystemWatcher()
        //{
        //    // Set up the file system watcher
        //    watcher = new FileSystemWatcher();
        //    watcher.Path = @"C:\file"; // Replace with your source folder path
        //    watcher.Filter = "*.*"; // Monitor all files, you can adjust this as needed
        //    watcher.IncludeSubdirectories = true;

        //    // Attach event handlers
        //    watcher.Created += OnFileChanged;
        //    watcher.Changed += OnFileChanged;

        //    // Start watching
        //    watcher.EnableRaisingEvents = true;
        //}

        //private void OnFileChanged(object sender, FileSystemEventArgs e)
        //{
        //    Thread thread = new Thread(() =>
        //    {
        //        lock (lockObject)
        //        {
        //            // Copy the file to the destination folder
        //            string destinationPath = @"C:\file1"; // Replace with your destination folder path
        //            string fileName = System.IO.Path.GetFileName(e.FullPath);
        //            string destinationFilePath = System.IO.Path.Combine(destinationPath, fileName);

        //            try
        //            {
        //                // Use File.Exists to check if the source file exists
        //                if (File.Exists(e.FullPath))
        //                {
        //                    File.Copy(e.FullPath, destinationFilePath, true);
        //                    // You can add additional logic here, such as updating the UI or logging
        //                }
        //            }
        //            catch (Exception ex)
        //            {
        //                // Handle exceptions
        //                MessageBox.Show("An error occurred: " + ex.Message);
        //            }
        //        }
        //    });

        //    thread.Start();
        //}
    }
}
